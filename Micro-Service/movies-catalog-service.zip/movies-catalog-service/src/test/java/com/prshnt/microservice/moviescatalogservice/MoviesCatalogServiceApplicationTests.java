package com.prshnt.microservice.moviescatalogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
